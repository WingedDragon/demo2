# -*- coding:utf-8 -*-

import numpy as np

def numpy_fun():
    print()


if __name__ == '__main__':
    numpy_fun()